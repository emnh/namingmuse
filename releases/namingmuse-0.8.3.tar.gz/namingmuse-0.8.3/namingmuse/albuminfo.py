""" A module that defines various albuminfo classes. An albuminfo class is a class that contains metdata about an album.
"""
import os, re, sys, string
import types
from albumtag import TAGVER
from exceptions import *
import pprint

class debugdumper(type):
    def __init__(cls, name, bases, dct):
        super(debugdumper, cls).__init__(name, bases, dct)
        def xrepr(self):
            s = "OBJECT DUMP of %s:\n" % name
            for key in dir(self):
                if key != "__init__":
                    value = eval("self. " + key)
                    if not callable(value):
                        s += "%s = %s\n" % (key, value)
            return s
        cls.dump = xrepr

class TagSafety(type):
    'A metaclass for adding helper methods guaranteeing tag completeness'
    
    def __init__(cls, name, bases, dct):
        super(TagSafety, cls).__init__(name, bases, dct)

        def strictGetString(self, prop):
            try:
                ret = eval("self._%s__%s" % (name, prop))
            except AttributeError:
                ret = eval("self._%s__%s" % (bases[0].__name__, prop))
                
            if isinstance(ret, types.StringTypes):
                ret = ret.strip()
            else:
                ret = ""
            if ret == "":
                raise TagIncompleteWarning(name + "." + prop)
            return ret

        def strictGetInt(self, prop):
            try:
                ret = eval("self._%s__%s" % (name, prop))
            except AttributeError:
                ret = eval("self._%s__%s" % (bases[0].__name__, prop))

            try:
                ret = int(ret)
            except ValueError:
                ret = 0
            if ret == 0:
                raise TagIncompleteWarning(name + "." + prop)
            return ret
        
        def weakGetString(self, prop):
            try:
                return strictGetString(self, prop)
            except TagIncompleteWarning:
                return ""

        def weakGetInt(self, prop):
            try:
                return strictGetInt(self, prop)
            except TagIncompleteWarning:
                return 0

        def ignoreMissing(self, truth):
            if truth: # be lenient
                self._getString = self._weakGetString
                self._getInt = self._weakGetInt
            else: # throw exceptions
                self._getString = self._strictGetString
                self._getInt = self._strictGetInt

        cls._getString = strictGetString
        cls._getInt = strictGetInt
        cls._strictGetString = strictGetString
        cls._strictGetInt = strictGetInt
        cls._weakGetString = weakGetString
        cls._weakGetInt = weakGetInt

        cls.ignoreMissing = ignoreMissing

class debugTagSafe(debugdumper, TagSafety): pass
#class debugTagSafe(TagSafety): pass

class TrackInfo(object):

    __metaclass__ = debugTagSafe
    
    __artist = ""
    __title = ""
    __number = 0
    __playLength = 0
    __isVarious = False
    
    
    # XXX: generate set/get methods from dict

    def validate(self):
        props = "artist", "title", "number", "playLength"
        missing = []
        for prop in props:
            try:
                eval("self." + prop)
            except TagIncompleteWarning, warn:
                missing.append(warn.getMissing())
        return missing
    
    def getArtist(self):
        return self._getString("artist")
    
    def setArtist(self, artist):
        self.__artist = artist

    def getTitle(self):
        return self._getString("title")

    def setTitle(self, title):
        self.__title = title

    def getPlayLength(self):
        return self._getInt("playLength")

    def setPlayLength(self, playlength):
        self.__playLength = playlength

    def getNumber(self):
        return self._getInt("number")
        
    def setNumber(self, number):
        self.__number = number

    def getIsVarious(self):
        return self.__isVarious
    
    def setIsVarious(self, isvarious):
        assert isinstance(isvarious, bool)
        self.__isVarious = isvarious

    artist = property(getArtist, setArtist)
    title = property(getTitle, setTitle)
    playLength = property(getPlayLength, setPlayLength)
    number = property(getNumber, setNumber)
    isVarious = property(getIsVarious, setIsVarious)

class AlbumInfo(object):
    __tagversion = TAGVER
    __year = 0
    __genre = ""
    __artist = ""
    __title = ""
    __tracks = []

    __metaclass__ = debugTagSafe

    def __init__(self, footprint):
        if footprint.has_key("TNMU"): 
            self.__tagversion = footprint["TNMU"]

    def validate(self):
        props = ("year", "genre", "artist", "title", "tracks")
        self.ignoreMissing(False)
        missing = []
        for prop in props:
            try:
                eval("self." + prop)
            except TagIncompleteWarning, warn:
                missing.append(warn.getMissing())
        for track in self.tracks:
            missing.extend(track.validate())
        self.ignoreMissing(True)
        return missing
    
    def getYear(self):
        year = self._getInt("year")
        #if year < 1800 or year > 3000:
        #    raise TagIncompleteWarning("album year")
        return year

    def setYear(self, year):
        self.__year = year

    def getGenre(self):
        return self._getString("genre")
    
    def setGenre(self, genre):
        # XXX: apply normalizing function
        # example: Alt Rock and Alt. Rock -> Alternative Rock
        self.__genre = genre

    def getArtist(self):
        return self._getString("artist")
    
    def setArtist(self, artist):
        self.__artist = artist

    def getTitle(self):
        return self._getString("title")

    def setTitle(self, title):
        self.__title = title

    def getTracks(self):
        for track in self.__tracks:
            assert isinstance(track, TrackInfo)
        return self.__tracks
    
    def setTracks(self, tracks):
        self.__tracks = tracks

    def getTagVersion(self):
        return self.__tagversion
        
    year = property(getYear, setYear)
    genre = property(getGenre, setGenre)
    artist = property(getArtist, setArtist)
    title = property(getTitle, setTitle)
    tracks = property(getTracks, setTracks)
    tagversion = property(getTagVersion)

class FreeDBAlbumInfo(AlbumInfo):
    __tagprovider = "freedb"
    __freedbrecord = None
    __readingrecord = False
    __cddb = None
    __freedbdiscid = None
    __freedbgenre = None

    def __getattribute__(self, name):
        #print "getattribute called:", name
        if name in ("year", "genre", "artist", "title", "tracks"):
            if not self.__readingrecord and not self.__freedbrecord:
                self.__readingrecord = True
                self.initRecord()
                self.__readingrecord = False
        return super(FreeDBAlbumInfo, self).__getattribute__(name)
    
    def initRecord(self):
        if not self.__cddb:
            raise NamingMuseError("FreeDBAlbumInfo bug: missing cddb connection object")
        discid = self.__freedbdiscid
        genre = self.__freedbgenre
        if not (discid and genre):
            raise NamingMuseError("FreeDBAlbumInfo: requested lookup without genre and discid")
        freedbrecord = self.__cddb.getRecord(genre, discid)
        self.parseFreedbRecord(freedbrecord)
        
    def footprint(self):
        footprint = {}
        footprint["TTPR"] = self.__tagprovider
        footprint["TCID"] = self.__freedbdiscid
        footprint["TGID"] = self.__freedbgenre
        return footprint

    def fromFootPrint(self, footprint):
        if footprint.has_key("tagprovider"): #XXX to be removed
            if footprint["tagprovider"] == self.__tagprovider:
                self.__freedbdiscid = footprint["cddbid"]
                self.__freedbgenre = footprint["genreid"]
            else:
                raise TypeError("invalid provider footprint (wrong class)")
        else:
            if footprint["TTPR"] == self.__tagprovider:
                self.__freedbdiscid = footprint["TCID"]
                self.__freedbgenre = footprint["TGID"]
            else:
                raise TypeError("invalid provider footprint (wrong class)")

    def setCDDBConnection(self, cddbobj):
        self.__cddb = cddbobj

    def __init__(self, *args):
        'Initialize albuminfo from freedb record'
        if len(args) > 1:
            if len(args) == 3:
                self.__cddb = args[0]
                self.__freedbgenre = args[1]
                self.__freedbdiscid  = args[2]
                return
            raise TypeError("invalid init arguments")
        else:
            if isinstance(args[0], types.StringTypes):
                freedbrecord = args[0]
                self.parseFreedbRecord(freedbrecord)
                return
            elif isinstance(args[0], dict):
                footprint = args[0]
                super(FreeDBAlbumInfo, self).__init__(footprint) 
                self.fromFootPrint(footprint)
                return
        raise TypeError("invalid init arguments")

    def parseFreedbRecord(self, freedbrecord):

        self.__freedbrecord = freedbrecord
        
        dbdict = {}
        linesep = "\r\n"
        lines = freedbrecord.split(linesep)[:-2]
        
        if not re.match("^# xmcd", lines[0]):
            raise NamingMuseError("invalid dbrecord signature: " + lines[0])

        # Convert freedb record to dictionary
        for line in lines:
            if not '#' == line[0]:
                key, value = line.split('=', 1)
                dbdict.setdefault(key, "")
                dbdict[key] += value

        # Set album fields from dbdict
        self.year = dbdict["DYEAR"]
        self.genre = dbdict["DGENRE"] # not limited to the 11 cddb genres
        if " / " in dbdict["DTITLE"]:
            self.artist, self.title = dbdict["DTITLE"].split(" / ", 1)
        else: 
            self.title = self.artist = dbdict["DTITLE"]
            
        # Set track fields from dbdict
        secs = self.extractTrackLengths(freedbrecord)
        tracks = []
        self.isVarious = False
        for key, value in dbdict.items():
            if key.startswith("TTITLE"):
                number = key[len("TTITLE"):]
                title = value
                number = int(number)
                t = TrackInfo()
                t.number = number + 1
                t.playLength = secs[number]
                if " / " in title:
                    self.isVarious = True
                    t.artist, t.title = title.split(" / ", 1) 
                else:
                    # inherit track artist from album
                    t.artist = self.artist
                    t.title = title
                tracks.append(t) 
        self.tracks = tracks

    def extractTrackLengths(self, cddbrecord):
        'Parse cddb record and calculate track lengths in seconds'

        pattern = '''
        # Match the header
        \#\ Track\ frame\ offsets:\s*

        # Match all the frame lines
        ((?:\#\s*[0-9]*\s*)+)

        # Eat blank comment lines
        [\s\#]*

        # Match total length
        Disc\ length:\ ([0-9]+)
        '''
        
        match = re.search(pattern, cddbrecord, re.X)
        if match:
            framestub = match.group(1)
            totalsecs = int(match.group(2))
        else:
            print cddbrecord
            raise NamingMuseError("invalid freedb record: " + \
                                  "couldn't parse frame offsets")
        
        # Convert frame comments to python list
        framestub = re.sub("\s*#\s*", ",", framestub)[2:-2]
        frames = eval("[" + framestub + "]")

        # Convert frame offsets to track playlengths
        secs = []
        for i in range(1, len(frames)):
            secs.append(int(round((frames[i] - frames[i - 1]) / 75.0)))
        secs.append(totalsecs - sum(secs)) # last song

        return secs

    def getEncoding(self):
        return self.__cddb.encoding
            
    encoding = property(getEncoding)
