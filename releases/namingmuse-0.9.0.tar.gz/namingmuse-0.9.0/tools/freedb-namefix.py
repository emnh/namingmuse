#!/usr/bin/env python

import sys, os, re

filename = sys.argv[1]

fd = file(filename)
record = fd.read()
fd.close()

newrecord = []
for line in record.splitlines():
    if line.startswith("TTITLE") or line.startswith("DTITLE"):
        key, value = line.split('=', 1)
        value = value.title()
        line = key + '=' + value
    newrecord.append(line)

newrecord = '\r\n'.join(newrecord)
fd = file(filename, 'wb')
fd.write(newrecord)
fd.close()
