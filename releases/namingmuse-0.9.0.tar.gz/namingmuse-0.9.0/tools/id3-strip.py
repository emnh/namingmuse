#!/usr/bin/env python

import os, re, sys
import TagLib
from glob import glob

dirname = sys.argv[1]
pattern = os.path.join(dirname, '*.mp3')

for filename in glob(pattern):
    print "Stripping " + filename
    ref = TagLib.MPEGFile(filename)
    ref.strip(TagLib.MPEGFile.AllTags)

