
'Contains global constants for namingmuse'

TAGVER = '0.03'
